nw.Window.open('https://stamp.archsted.com/broadcaster',
    {
        "frame": false,
        "transparent": true,
        "always_on_top":true,
        "fullscreen": true
    }, function(new_win) {
    	
    }
);